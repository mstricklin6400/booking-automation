# Appointment Booking Automation

A Python application that automates booking appointments by reading data from Google Sheets and using web automation to fill out booking forms.

## Features

- 📊 **Google Sheets Integration**: Reads appointment data directly from your Google Spreadsheet
- 🤖 **Web Automation**: Uses Playwright to automate booking form submission
- 🖥️ **Web Dashboard**: Clean web interface to monitor and control automation
- 📝 **Error Logging**: Comprehensive logging and failed booking tracking
- ⚙️ **Configurable**: Easy configuration via environment variables
- 🔒 **Secure**: Uses Google Service Account authentication
- 📧 **Email Notifications**: Get instant notifications for successful bookings, failures, and automation summaries

## Quick Start

### 🚀 For Replit Users (Easiest)

1. **Fork this Replit**: Click the "Fork" button to copy this project to your account
2. **Configure via Web Interface**: Once forked, use the "Configure URLs" button in the web dashboard
3. **Add Google Credentials**: Upload your `credentials.json` file to the project root
4. **Start Automating**: Use the web interface to start booking appointments

**Complete setup in under 5 minutes!** See [SHARING_GUIDE.md](SHARING_GUIDE.md) for detailed instructions.

### 🔧 Manual Setup

#### 1. Setup Google Sheets API

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable the Google Sheets API and Google Drive API
4. Create a Service Account in "IAM & Admin" > "Service Accounts"
5. Download the JSON credentials file
6. Rename it to `credentials.json` and place it in the project root
7. Share your Google Sheet with the service account email address

### 2. Prepare Your Google Sheet

Your spreadsheet should have these columns:
- **Column A**: Name (required)
- **Column B**: Email (required)  
- **Column C**: Company (optional)
- **Column D**: Status (will be updated to "done" after successful booking)

#### 3. Configure URLs

**Easy Way** (Web Interface):
1. Run `python app.py`
2. Click "Configure URLs" in the web dashboard
3. Enter your Google Sheet URL and LeadConnector booking URL

**Advanced Way** (Environment Variables):
Set the required environment variables as shown in the Configuration section below.

#### 4. Run the Application

**Web Interface** (Recommended):
```bash
python app.py
```
Then open the web dashboard to control the automation.

**Command Line**:
```bash
python main.py
```

## Configuration

You can customize the app using environment variables:

```bash
# Required
SPREADSHEET_URL="your-google-sheet-url-or-id"

# Optional - Basic Configuration
BOOKING_URL="https://api.leadconnectorhq.com/widget/booking/vggoBfO4Zr1RTp4M4h8m"
HEADLESS_MODE="true"  # Set to "false" to see browser automation
GOOGLE_CREDS_FILE="credentials.json"
FLASK_PORT="5000"

# Optional - Email Notifications
SENDGRID_API_KEY="your-sendgrid-api-key"
NOTIFICATION_EMAIL="your-email@example.com"
FROM_EMAIL="noreply@bookingautomation.com"
EMAIL_NOTIFICATIONS_ENABLED="true"
NOTIFY_ON_SUCCESS="true"
NOTIFY_ON_FAILURE="true"
NOTIFY_ON_SUMMARY="true"
```

## Web Dashboard Features

- **Control Panel**: Start/stop automation with one click
- **Real-time Status**: See current automation status and progress
- **Configuration View**: Check your setup and credentials
- **Log Viewer**: Monitor automation activity in real-time
- **Failed Bookings**: Track and review any failed booking attempts

## How It Works

1. **Reads Google Sheet**: Connects to your spreadsheet and loads appointment data
2. **Filters Rows**: Skips any rows where Column D already says "done"
3. **Opens Booking Page**: Uses Playwright browser automation to navigate to the booking site
4. **Fills Form**: Automatically selects first available date/time and fills in contact details
5. **Submits Booking**: Completes the appointment booking process
6. **Updates Sheet**: Marks the row as "done" in Column D after successful booking
7. **Error Handling**: Logs any failures for review and retry

## Troubleshooting

### Common Issues

1. **"Credentials file not found"**
   - Make sure `credentials.json` is in the project root
   - Verify the file isn't named `credentials.json.txt`

2. **"Permission denied" on Google Sheets**
   - Share your sheet with the service account email
   - Check that the APIs are enabled in Google Cloud Console

3. **Browser automation fails**
   - Try setting `HEADLESS_MODE=false` to see what's happening
   - Check the booking website URL is correct

4. **No available appointment slots**
   - The automation selects the first available date/time
   - If none are available, the booking will fail and be logged

### Log Files

- `booking_errors.log`: General application logs and errors
- `failed_bookings.log`: Detailed information about failed booking attempts

## Development

The application is structured as follows:

- `main.py`: Command-line entry point
- `app.py`: Flask web application
- `booking_automation.py`: Core automation logic
- `config.py`: Configuration management
- `templates/`: Web interface templates
- `static/`: CSS and JavaScript files

## Security Notes

- Keep your `credentials.json` file secure and never commit it to version control
- The service account only needs access to your specific Google Sheet
- All web automation is performed in a sandboxed browser environment

## Support

If you encounter issues:

1. Check the web dashboard logs for detailed error information
2. Review the failed bookings log for specific booking failures
3. Verify your Google Sheets setup and permissions
4. Ensure the booking website URL is correct and accessible