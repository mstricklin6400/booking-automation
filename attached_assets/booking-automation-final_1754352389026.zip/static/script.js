// JavaScript for the booking automation web interface

let statusCheckInterval;

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    updateCurrentTime();
    setInterval(updateCurrentTime, 1000);
    
    refreshStatus();
    loadConfiguration();
    
    // Set up event listeners
    document.getElementById('run-automation-btn').addEventListener('click', runAutomation);
    
    // Start periodic status checking
    startStatusChecking();
});

// Update the current time display
function updateCurrentTime() {
    const now = new Date();
    const timeString = now.toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });
    document.getElementById('current-time').textContent = timeString;
}

// Start periodic status checking
function startStatusChecking() {
    statusCheckInterval = setInterval(refreshStatus, 3000); // Check every 3 seconds
}

// Stop periodic status checking
function stopStatusChecking() {
    if (statusCheckInterval) {
        clearInterval(statusCheckInterval);
    }
}

// Refresh automation status
function refreshStatus() {
    fetch('/status')
        .then(response => response.json())
        .then(data => {
            updateStatusDisplay(data);
        })
        .catch(error => {
            console.error('Error fetching status:', error);
            showErrorMessage('Failed to fetch status');
        });
}

// Update the status display
function updateStatusDisplay(status) {
    const indicator = document.getElementById('status-indicator');
    const statusText = document.getElementById('status-text');
    const runBtn = document.getElementById('run-automation-btn');
    const lastRunInfo = document.getElementById('last-run-info');
    const automationStatus = document.querySelector('.automation-status');
    
    // Remove all status classes
    indicator.className = 'status-indicator me-2';
    automationStatus.className = 'automation-status mb-3';
    
    if (status.running) {
        indicator.classList.add('status-running');
        statusText.textContent = 'Running...';
        runBtn.disabled = true;
        runBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Running...';
        automationStatus.classList.add('running');
    } else {
        runBtn.disabled = false;
        runBtn.innerHTML = '<i class="fas fa-play"></i> Run Automation';
        
        if (status.last_result) {
            if (status.last_result.success) {
                indicator.classList.add('status-success');
                statusText.textContent = 'Last run successful';
                automationStatus.classList.add('success');
            } else {
                indicator.classList.add('status-error');
                statusText.textContent = 'Last run failed';
                automationStatus.classList.add('error');
            }
        } else {
            indicator.classList.add('status-ready');
            statusText.textContent = 'Ready';
        }
    }
    
    // Update last run information
    if (status.last_run) {
        document.getElementById('last-run-time').textContent = status.last_run;
        if (status.last_result) {
            const resultText = status.last_result.success 
                ? `Success (${status.last_result.failed_count} failed bookings)`
                : status.last_result.message;
            document.getElementById('last-run-result').textContent = resultText;
        }
        lastRunInfo.style.display = 'block';
    } else {
        lastRunInfo.style.display = 'none';
    }
}

// Run the automation
function runAutomation() {
    const button = document.getElementById('run-automation-btn');
    button.disabled = true;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Starting...';
    
    fetch('/run_automation', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccessMessage(data.message);
        } else {
            showErrorMessage(data.message);
            button.disabled = false;
            button.innerHTML = '<i class="fas fa-play"></i> Run Automation';
        }
    })
    .catch(error => {
        console.error('Error running automation:', error);
        showErrorMessage('Failed to start automation');
        button.disabled = false;
        button.innerHTML = '<i class="fas fa-play"></i> Run Automation';
    });
}

// Load and display configuration
function loadConfiguration() {
    fetch('/config')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayConfiguration(data.config);
            } else {
                showErrorMessage('Failed to load configuration');
            }
        })
        .catch(error => {
            console.error('Error loading configuration:', error);
            showErrorMessage('Failed to load configuration');
        });
}

// Display configuration information
function displayConfiguration(config) {
    const container = document.getElementById('config-info');
    
    const configItems = [
        { label: 'Spreadsheet URL', value: config.spreadsheet_url, type: 'url' },
        { label: 'Booking URL', value: config.booking_url, type: 'url' },
        { label: 'Sheet Name', value: config.sheet_name, type: 'text' },
        { label: 'Headless Mode', value: config.headless_mode ? 'Yes' : 'No', type: 'text' },
        { label: 'Credentials File', value: config.credentials_file_exists ? 'Found' : 'Missing', type: 'status' },
        { label: 'Email Notifications', value: config.notifications_enabled ? 'Enabled' : 'Disabled', type: 'status' },
        { label: 'SendGrid API Key', value: config.sendgrid_configured ? 'Configured' : 'Missing', type: 'status' },
        { label: 'Notification Email', value: config.notification_email_set ? 'Set' : 'Missing', type: 'status' }
    ];
    
    let html = '';
    configItems.forEach(item => {
        let valueClass = '';
        let valueContent = item.value;
        
        if (item.type === 'status') {
            if (item.label === 'Email Notifications') {
                valueClass = item.value === 'Enabled' ? 'text-success' : 'text-warning';
            } else {
                valueClass = ['Found', 'Configured', 'Set', 'Enabled'].includes(item.value) ? 'text-success' : 'text-danger';
            }
        } else if (item.type === 'url') {
            valueContent = truncateUrl(item.value);
        }
        
        html += `
            <div class="config-item">
                <span class="config-label">${item.label}:</span>
                <span class="config-value ${valueClass}" title="${item.value}">${valueContent}</span>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Truncate long URLs for display
function truncateUrl(url) {
    if (url.length > 50) {
        return url.substring(0, 30) + '...' + url.substring(url.length - 15);
    }
    return url;
}

// Refresh logs
function refreshLogs() {
    const container = document.getElementById('logs-container');
    container.innerHTML = '<div class="text-center"><div class="spinner-border spinner-border-sm" role="status"></div> Loading logs...</div>';
    
    fetch('/logs')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayLogs(data.logs);
            } else {
                container.innerHTML = `<div class="text-danger">Error: ${data.message}</div>`;
            }
        })
        .catch(error => {
            console.error('Error fetching logs:', error);
            container.innerHTML = '<div class="text-danger">Failed to load logs</div>';
        });
}

// Display logs
function displayLogs(logs) {
    const container = document.getElementById('logs-container');
    
    if (logs.length === 0) {
        container.innerHTML = '<div class="text-muted">No logs available</div>';
        return;
    }
    
    let html = '';
    logs.forEach(line => {
        const logClass = getLogClass(line);
        html += `<div class="log-line ${logClass}">${escapeHtml(line.trim())}</div>`;
    });
    
    container.innerHTML = html;
    container.scrollTop = container.scrollHeight; // Scroll to bottom
}

// Get CSS class for log line based on content
function getLogClass(line) {
    if (line.includes('ERROR')) return 'log-error';
    if (line.includes('WARNING')) return 'log-warning';
    if (line.includes('INFO')) return 'log-info';
    return '';
}

// Refresh failed bookings
function refreshFailedBookings() {
    const container = document.getElementById('failed-bookings-container');
    container.innerHTML = '<div class="text-center"><div class="spinner-border spinner-border-sm" role="status"></div> Loading failed bookings...</div>';
    
    fetch('/failed_bookings')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayFailedBookings(data.failed_bookings);
            } else {
                container.innerHTML = `<div class="text-danger">Error: ${data.message}</div>`;
            }
        })
        .catch(error => {
            console.error('Error fetching failed bookings:', error);
            container.innerHTML = '<div class="text-danger">Failed to load failed bookings</div>';
        });
}

// Display failed bookings
function displayFailedBookings(failedBookings) {
    const container = document.getElementById('failed-bookings-container');
    
    if (failedBookings.length === 0) {
        container.innerHTML = '<div class="text-muted">No failed bookings</div>';
        return;
    }
    
    let html = '';
    failedBookings.forEach(booking => {
        html += `
            <div class="failed-booking-item">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <strong>${escapeHtml(booking.name)}</strong>
                        <div class="text-muted small">${escapeHtml(booking.email)}</div>
                        ${booking.company ? `<div class="text-muted small">${escapeHtml(booking.company)}</div>` : ''}
                    </div>
                    <div class="timestamp">${booking.timestamp}</div>
                </div>
                <div class="mt-2 text-danger small">
                    <i class="fas fa-exclamation-triangle"></i>
                    ${escapeHtml(booking.error)}
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

// Show success message
function showSuccessMessage(message) {
    showToast(message, 'success');
}

// Show error message
function showErrorMessage(message) {
    showToast(message, 'danger');
}

// Show toast notification
function showToast(message, type) {
    // Create toast element
    const toastId = 'toast-' + Date.now();
    const toastHtml = `
        <div class="toast align-items-center text-white bg-${type} border-0" id="${toastId}" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    ${escapeHtml(message)}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    `;
    
    // Add to toast container (create if doesn't exist)
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
        toastContainer.style.zIndex = '1060';
        document.body.appendChild(toastContainer);
    }
    
    toastContainer.insertAdjacentHTML('beforeend', toastHtml);
    
    // Show toast
    const toastElement = document.getElementById(toastId);
    const toast = new bootstrap.Toast(toastElement, {
        autohide: true,
        delay: 5000
    });
    toast.show();
    
    // Remove from DOM after hiding
    toastElement.addEventListener('hidden.bs.toast', function() {
        toastElement.remove();
    });
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Handle page visibility changes to pause/resume status checking
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        stopStatusChecking();
    } else {
        startStatusChecking();
    }
});

// Test email configuration
function testEmailConfiguration() {
    const button = document.getElementById('test-email-btn');
    const originalContent = button.innerHTML;
    
    button.disabled = true;
    button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Testing...';
    
    fetch('/test_email', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccessMessage('Test email sent successfully! Check your inbox.');
        } else {
            const error = data.result?.error || data.error || 'Email test failed';
            showErrorMessage(`Email test failed: ${error}`);
        }
    })
    .catch(error => {
        console.error('Error testing email:', error);
        showErrorMessage('Failed to test email configuration');
    })
    .finally(() => {
        button.disabled = false;
        button.innerHTML = originalContent;
    });
}

// Open configuration modal
function openConfigModal() {
    fetch('/get_config_form')
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            populateConfigForm(data.config);
            const modal = new bootstrap.Modal(document.getElementById('configModal'));
            modal.show();
        } else {
            showErrorMessage('Failed to load configuration');
        }
    })
    .catch(error => {
        console.error('Error loading config:', error);
        showErrorMessage('Failed to load configuration');
    });
}

// Populate configuration form with current values
function populateConfigForm(config) {
    document.getElementById('spreadsheetUrl').value = config.SPREADSHEET_URL || '';
    document.getElementById('sheetName').value = config.SHEET_NAME || 'Sheet1';
    document.getElementById('bookingUrl').value = config.BOOKING_URL || '';
    document.getElementById('headlessMode').checked = config.HEADLESS_MODE !== 'false';
    document.getElementById('notificationEmail').value = config.NOTIFICATION_EMAIL || '';
    document.getElementById('fromEmail').value = config.FROM_EMAIL || 'noreply@bookingautomation.com';
    document.getElementById('notifySuccess').checked = config.NOTIFY_ON_SUCCESS !== 'false';
    document.getElementById('notifyFailure').checked = config.NOTIFY_ON_FAILURE !== 'false';
    document.getElementById('notifySummary').checked = config.NOTIFY_ON_SUMMARY !== 'false';
}

// Save configuration
function saveConfiguration() {
    const form = document.getElementById('configForm');
    const formData = new FormData(form);
    const config = {};
    
    // Convert form data to object
    for (let [key, value] of formData.entries()) {
        if (key.includes('HEADLESS_MODE') || key.includes('NOTIFY_')) {
            config[key] = 'true';
        } else {
            config[key] = value;
        }
    }
    
    // Handle checkboxes that weren't checked
    const checkboxes = ['HEADLESS_MODE', 'NOTIFY_ON_SUCCESS', 'NOTIFY_ON_FAILURE', 'NOTIFY_ON_SUMMARY'];
    checkboxes.forEach(checkbox => {
        if (!(checkbox in config)) {
            config[checkbox] = 'false';
        }
    });
    
    // Validate required fields
    if (!config.SPREADSHEET_URL) {
        showErrorMessage('Google Sheet URL is required');
        return;
    }
    
    if (!config.BOOKING_URL) {
        showErrorMessage('LeadConnector Booking URL is required');
        return;
    }
    
    // Save configuration
    fetch('/update_config', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(config)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showSuccessMessage('Configuration saved successfully!');
            const modal = bootstrap.Modal.getInstance(document.getElementById('configModal'));
            modal.hide();
            // Refresh configuration display
            loadConfigInfo();
        } else {
            showErrorMessage(`Failed to save configuration: ${data.error}`);
        }
    })
    .catch(error => {
        console.error('Error saving config:', error);
        showErrorMessage('Failed to save configuration');
    });
}

// Clean up on page unload
window.addEventListener('beforeunload', function() {
    stopStatusChecking();
});
