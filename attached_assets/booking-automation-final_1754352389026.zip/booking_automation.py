"""
Core booking automation module that handles Google Sheets integration
and Playwright web automation for appointment booking.
"""

import gspread
from oauth2client.service_account import ServiceAccountCredentials
from playwright.sync_api import sync_playwright
import time
import json
import logging
import os
from datetime import datetime
from config import Config
from email_service import EmailService

class BookingAutomation:
    def __init__(self):
        self.config = Config()
        self.logger = logging.getLogger(__name__)
        self.sheet = None
        self.failed_bookings = []
        self.email_service = EmailService()
        self.start_time = None
        
    def get_sheet(self):
        """Connect to Google Sheets and return the worksheet"""
        try:
            # Check if credentials file exists
            if not os.path.exists(self.config.CREDS_FILE):
                raise FileNotFoundError(f"Credentials file not found: {self.config.CREDS_FILE}")
            
            creds = ServiceAccountCredentials.from_json_keyfile_name(
                self.config.CREDS_FILE, 
                scopes=self.config.SCOPE
            )
            client = gspread.authorize(creds)
            
            # Try to open by URL first, then by key if that fails
            try:
                if self.config.SPREADSHEET_URL.startswith('http'):
                    sheet = client.open_by_url(self.config.SPREADSHEET_URL).sheet1
                else:
                    sheet = client.open_by_key(self.config.SPREADSHEET_URL).sheet1
            except Exception as e:
                self.logger.error(f"Failed to open spreadsheet: {str(e)}")
                raise
                
            self.logger.info("Successfully connected to Google Sheets")
            return sheet
            
        except Exception as e:
            self.logger.error(f"Error connecting to Google Sheets: {str(e)}")
            raise

    def mark_done(self, row_num):
        """Mark a row as done in the Google Sheet"""
        try:
            self.sheet.update_cell(row_num, 4, "done")
            self.logger.info(f"Marked row {row_num} as done")
        except Exception as e:
            self.logger.error(f"Error marking row {row_num} as done: {str(e)}")
            raise

    def book_appointment(self, name, email, company):
        """
        Use Playwright to automate appointment booking on LeadConnector
        """
        try:
            with sync_playwright() as p:
                # Launch browser in headless mode for production
                browser = p.chromium.launch(
                    headless=self.config.HEADLESS_MODE,
                    args=['--no-sandbox', '--disable-dev-shm-usage']
                )
                page = browser.new_page()
                
                # Set a reasonable timeout
                page.set_default_timeout(30000)
                
                self.logger.info(f"Navigating to booking page for {name}")
                page.goto(self.config.BOOKING_URL)
                
                # Wait for page to load completely
                page.wait_for_load_state('networkidle')
                
                # Wait and click first available day
                self.logger.info("Looking for available day...")
                try:
                    page.wait_for_selector("button.day:not([disabled])", timeout=15000)
                    available_days = page.query_selector_all("button.day:not([disabled])")
                    if not available_days:
                        raise Exception("No available days found")
                    
                    # Click the first available day
                    available_days[0].click()
                    self.logger.info("Selected first available day")
                    
                except Exception as e:
                    self.logger.error(f"Error selecting day: {str(e)}")
                    browser.close()
                    return False

                # Wait for time slots to load and click first available time
                time.sleep(2)
                try:
                    page.wait_for_selector("button.time", timeout=10000)
                    time_slots = page.query_selector_all("button.time")
                    if not time_slots:
                        raise Exception("No time slots found")
                    
                    # Click the first available time slot
                    time_slots[0].click()
                    self.logger.info("Selected first available time slot")
                    
                except Exception as e:
                    self.logger.error(f"Error selecting time slot: {str(e)}")
                    browser.close()
                    return False

                # Wait for form to appear
                time.sleep(2)
                
                # Fill in the form fields
                try:
                    self.logger.info("Filling form fields...")
                    
                    # Try different possible selectors for form fields
                    name_selectors = [
                        "input[name='name']",
                        "input[placeholder*='name']",
                        "input[id*='name']",
                        "#name"
                    ]
                    
                    email_selectors = [
                        "input[name='email']",
                        "input[type='email']",
                        "input[placeholder*='email']",
                        "input[id*='email']",
                        "#email"
                    ]
                    
                    company_selectors = [
                        "input[name='company']",
                        "input[placeholder*='company']",
                        "input[id*='company']",
                        "#company"
                    ]
                    
                    # Fill name field
                    name_filled = False
                    for selector in name_selectors:
                        try:
                            if page.query_selector(selector):
                                page.fill(selector, name)
                                name_filled = True
                                break
                        except:
                            continue
                    
                    if not name_filled:
                        raise Exception("Could not find name input field")
                    
                    # Fill email field
                    email_filled = False
                    for selector in email_selectors:
                        try:
                            if page.query_selector(selector):
                                page.fill(selector, email)
                                email_filled = True
                                break
                        except:
                            continue
                    
                    if not email_filled:
                        raise Exception("Could not find email input field")
                    
                    # Fill company field
                    company_filled = False
                    for selector in company_selectors:
                        try:
                            if page.query_selector(selector):
                                page.fill(selector, company)
                                company_filled = True
                                break
                        except:
                            continue
                    
                    if not company_filled:
                        self.logger.warning("Could not find company input field, continuing without it")
                    
                    self.logger.info("Form fields filled successfully")
                    
                except Exception as e:
                    self.logger.error(f"Error filling form fields: {str(e)}")
                    browser.close()
                    return False

                # Submit the form
                try:
                    submit_selectors = [
                        "button[type='submit']",
                        "input[type='submit']",
                        "button:has-text('Submit')",
                        "button:has-text('Book')",
                        ".submit-btn",
                        "#submit"
                    ]
                    
                    submitted = False
                    for selector in submit_selectors:
                        try:
                            if page.query_selector(selector):
                                page.click(selector)
                                submitted = True
                                break
                        except:
                            continue
                    
                    if not submitted:
                        raise Exception("Could not find submit button")
                    
                    self.logger.info("Form submitted successfully")
                    
                    # Wait for submission to complete
                    time.sleep(4)
                    
                except Exception as e:
                    self.logger.error(f"Error submitting form: {str(e)}")
                    browser.close()
                    return False

                browser.close()
                self.logger.info(f"Successfully booked appointment for {name}")
                return True
                
        except Exception as e:
            self.logger.error(f"Unexpected error booking appointment for {name}: {str(e)}")
            return False

    def log_failed_booking(self, row_data, error_message):
        """Log failed booking attempts to a separate log file"""
        failed_entry = {
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'name': row_data.get('Name', ''),
            'email': row_data.get('Email', ''),
            'company': row_data.get('Company', ''),
            'error': error_message
        }
        
        self.failed_bookings.append(failed_entry)
        
        # Write to failed bookings log file
        try:
            with open('failed_bookings.log', 'a') as f:
                f.write(f"{json.dumps(failed_entry)}\n")
        except Exception as e:
            self.logger.error(f"Error writing to failed bookings log: {str(e)}")

    def run(self):
        """Main execution method"""
        self.start_time = datetime.now()
        
        try:
            # Connect to Google Sheets
            self.sheet = self.get_sheet()
            
            # Get all records from the sheet
            data = self.sheet.get_all_records()
            
            if not data:
                self.logger.warning("No data found in the spreadsheet")
                return
            
            self.logger.info(f"Found {len(data)} rows to process")
            
            processed_count = 0
            success_count = 0
            skip_count = 0
            
            # Process each row
            for i, row in enumerate(data):
                try:
                    # Check if already done
                    status = str(row.get("Status", "")).strip().lower()
                    if status == "done":
                        skip_count += 1
                        self.logger.info(f"Skipping row {i+2} - already marked as done")
                        continue
                    
                    # Extract data
                    name = str(row.get("Name", "")).strip()
                    email = str(row.get("Email", "")).strip()
                    company = str(row.get("Company", "")).strip()
                    
                    # Validate required fields
                    if not name or not email:
                        error_msg = f"Missing required fields (name: '{name}', email: '{email}')"
                        self.logger.error(f"Row {i+2}: {error_msg}")
                        self.log_failed_booking(row, error_msg)
                        continue
                    
                    self.logger.info(f"Processing row {i+2}: Booking for {name} ({email})")
                    
                    # Attempt to book appointment
                    success = self.book_appointment(name, email, company)
                    
                    if success:
                        # Mark as done in the sheet
                        try:
                            self.mark_done(i + 2)  # Add 2 because get_all_records skips header and gspread is 1-indexed
                            success_count += 1
                            self.logger.info(f"✅ Successfully booked and marked done for {name}")
                            
                            # Send success notification email
                            if self.config.EMAIL_NOTIFICATIONS_ENABLED and self.config.NOTIFY_ON_SUCCESS:
                                booking_data = {
                                    'name': name,
                                    'email': email,
                                    'company': company,
                                    'row_number': i + 2
                                }
                                self.email_service.send_booking_success_notification(booking_data)
                                
                        except Exception as e:
                            self.logger.error(f"Booking succeeded but failed to mark as done for {name}: {str(e)}")
                            self.log_failed_booking(row, f"Booking succeeded but marking failed: {str(e)}")
                    else:
                        self.logger.error(f"❌ Failed to book appointment for {name}")
                        error_message = "Booking automation failed"
                        self.log_failed_booking(row, error_message)
                        
                        # Send failure notification email
                        if self.config.EMAIL_NOTIFICATIONS_ENABLED and self.config.NOTIFY_ON_FAILURE:
                            booking_data = {
                                'name': name,
                                'email': email,
                                'company': company,
                                'row_number': i + 2
                            }
                            self.email_service.send_booking_failure_notification(booking_data, error_message)
                    
                    processed_count += 1
                    
                    # Add a small delay between bookings to be respectful
                    if processed_count < len(data) - skip_count:
                        time.sleep(2)
                        
                except Exception as e:
                    self.logger.error(f"Error processing row {i+2}: {str(e)}")
                    self.log_failed_booking(row, f"Processing error: {str(e)}")
                    continue
            
            # Calculate duration
            end_time = datetime.now()
            duration = end_time - self.start_time if self.start_time else None
            duration_str = str(duration).split('.')[0] if duration else "Unknown"
            
            # Summary
            self.logger.info("=" * 50)
            self.logger.info("AUTOMATION SUMMARY")
            self.logger.info("=" * 50)
            self.logger.info(f"Total rows processed: {processed_count}")
            self.logger.info(f"Successful bookings: {success_count}")
            self.logger.info(f"Skipped (already done): {skip_count}")
            self.logger.info(f"Failed bookings: {len(self.failed_bookings)}")
            self.logger.info(f"Duration: {duration_str}")
            
            if self.failed_bookings:
                self.logger.warning(f"Check 'failed_bookings.log' for details on {len(self.failed_bookings)} failed attempts")
            
            # Send automation summary email
            if self.config.EMAIL_NOTIFICATIONS_ENABLED and self.config.NOTIFY_ON_SUMMARY:
                summary_data = {
                    'total_processed': processed_count,
                    'successful': success_count,
                    'failed': len(self.failed_bookings),
                    'skipped': skip_count,
                    'duration': duration_str
                }
                self.email_service.send_automation_summary(summary_data)
            
        except Exception as e:
            self.logger.error(f"Critical error in automation: {str(e)}")
            raise
