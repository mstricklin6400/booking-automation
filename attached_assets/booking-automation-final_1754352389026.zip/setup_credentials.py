#!/usr/bin/env python3
"""
Interactive setup script to help configure Google Service Account credentials.
"""

import json
import os
import sys

def main():
    print("🔧 Google Service Account Setup Helper")
    print("=" * 50)
    
    # Check if credentials already exist
    if os.path.exists("credentials.json"):
        print("✅ credentials.json already exists!")
        
        try:
            with open("credentials.json", "r") as f:
                creds = json.load(f)
                
            print(f"📧 Service Account Email: {creds.get('client_email', 'Not found')}")
            print(f"📋 Project ID: {creds.get('project_id', 'Not found')}")
            
            response = input("\nDo you want to replace these credentials? (y/N): ")
            if response.lower() != 'y':
                print("Setup cancelled.")
                return
                
        except Exception as e:
            print(f"⚠️  Warning: Existing credentials file is invalid: {e}")
    
    print("\n📋 To set up Google Service Account credentials:")
    print("1. Go to https://console.cloud.google.com/")
    print("2. Create a new project or select an existing one")
    print("3. Enable the Google Sheets API and Google Drive API")
    print("4. Go to 'IAM & Admin' > 'Service Accounts'")
    print("5. Create a new service account")
    print("6. Download the JSON key file")
    print("7. Share your Google Sheet with the service account email")
    
    print("\n" + "="*50)
    print("Choose setup method:")
    print("1. Copy/paste JSON credentials")
    print("2. Upload JSON file path")
    print("3. Exit")
    
    choice = input("\nEnter your choice (1-3): ").strip()
    
    if choice == "1":
        setup_from_paste()
    elif choice == "2":
        setup_from_file()
    elif choice == "3":
        print("Setup cancelled.")
        return
    else:
        print("Invalid choice. Exiting.")
        return

def setup_from_paste():
    print("\n📋 Paste your Google Service Account JSON credentials below.")
    print("(Paste the entire JSON content and press Enter twice when done)")
    
    lines = []
    print("JSON content:")
    
    try:
        while True:
            line = input()
            if line.strip() == "" and lines:
                break
            lines.append(line)
        
        json_content = "\n".join(lines)
        
        # Validate JSON
        creds = json.loads(json_content)
        
        # Validate required fields
        required_fields = ["type", "project_id", "private_key", "client_email"]
        missing_fields = [field for field in required_fields if field not in creds]
        
        if missing_fields:
            print(f"❌ Error: Missing required fields: {', '.join(missing_fields)}")
            return
        
        if creds.get("type") != "service_account":
            print("❌ Error: This doesn't appear to be a service account credential file.")
            return
        
        # Save to file
        with open("credentials.json", "w") as f:
            json.dump(creds, f, indent=2)
        
        print("✅ Credentials saved successfully!")
        print(f"📧 Service Account Email: {creds['client_email']}")
        print(f"📋 Project ID: {creds['project_id']}")
        print("\n🔗 Remember to share your Google Sheet with this email address!")
        
    except json.JSONDecodeError as e:
        print(f"❌ Error: Invalid JSON format: {e}")
    except KeyboardInterrupt:
        print("\n\nSetup cancelled.")
    except Exception as e:
        print(f"❌ Error: {e}")

def setup_from_file():
    print("\n📁 Enter the path to your Google Service Account JSON file:")
    file_path = input("File path: ").strip()
    
    if not os.path.exists(file_path):
        print(f"❌ Error: File not found: {file_path}")
        return
    
    try:
        with open(file_path, "r") as f:
            creds = json.load(f)
        
        # Validate required fields
        required_fields = ["type", "project_id", "private_key", "client_email"]
        missing_fields = [field for field in required_fields if field not in creds]
        
        if missing_fields:
            print(f"❌ Error: Missing required fields: {', '.join(missing_fields)}")
            return
        
        if creds.get("type") != "service_account":
            print("❌ Error: This doesn't appear to be a service account credential file.")
            return
        
        # Copy to credentials.json
        with open("credentials.json", "w") as f:
            json.dump(creds, f, indent=2)
        
        print("✅ Credentials copied successfully!")
        print(f"📧 Service Account Email: {creds['client_email']}")
        print(f"📋 Project ID: {creds['project_id']}")
        print("\n🔗 Remember to share your Google Sheet with this email address!")
        
    except json.JSONDecodeError as e:
        print(f"❌ Error: Invalid JSON format: {e}")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    main()