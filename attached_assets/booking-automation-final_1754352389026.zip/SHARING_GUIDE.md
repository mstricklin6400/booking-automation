# Sharing Guide: Making This Project Your Own

This guide will help you fork this project to your own Replit account and set it up for your own use.

## 🚀 Quick Setup (For Replit Users)

### Step 1: Fork the Project
1. Click the "Fork" button in the top-right corner of this Replit
2. This will create a copy in your own Replit account
3. The project will automatically install dependencies when you open it

### Step 2: Set Up Google Sheets Integration
1. Create a Google Service Account:
   - Go to [Google Cloud Console](https://console.cloud.google.com/)
   - Create a new project or select existing one
   - Enable Google Sheets API and Google Drive API
   - Create credentials → Service Account
   - Download the JSON key file

2. Upload credentials to your Replit:
   - In your forked Replit, upload the JSON file as `credentials.json`
   - Make sure it's in the root directory

3. Share your Google Sheet:
   - Open your Google Sheet
   - Click "Share" button
   - Add the service account email (found in credentials.json) as an editor
   - Copy the sheet URL

### Step 3: Configure URLs (Easy Way)
1. Open your web app (it should start automatically)
2. Click the "Configure URLs" button
3. Fill in:
   - **Google Sheet URL**: Your Google Sheets URL
   - **LeadConnector Booking URL**: Your booking widget URL
   - **Other settings**: Adjust as needed

### Step 4: Set Up Email Notifications (Optional)
1. Get a SendGrid API key:
   - Sign up at [SendGrid](https://sendgrid.com/)
   - Create an API key
   
2. Add the API key as a secret:
   - In Replit, go to the "Secrets" tab (lock icon)
   - Add: `SENDGRID_API_KEY` with your SendGrid API key
   - Add: `NOTIFICATION_EMAIL` with your email address

3. Test email functionality using the "Test Email" button

## 🔧 Advanced Configuration

### Environment Variables (Optional)
You can also configure the app using Replit Secrets instead of the web interface:

```
SPREADSHEET_URL=your-google-sheet-url
BOOKING_URL=your-leadconnector-booking-url
SHEET_NAME=Sheet1
HEADLESS_MODE=true
NOTIFICATION_EMAIL=your-email@example.com
FROM_EMAIL=noreply@yourdomain.com
SENDGRID_API_KEY=your-sendgrid-api-key
```

### Google Sheet Format
Your Google Sheet should have these columns:
- **Column A**: Name
- **Column B**: Email  
- **Column C**: Company
- **Column D**: Status (will be updated to "Booked" when successful)

Example:
```
Name          | Email                | Company      | Status
John Doe      | john@example.com     | Acme Corp    | 
Jane Smith    | jane@company.com     | Tech Inc     |
```

## 🚀 Running the App

1. The web interface will start automatically at port 5000
2. Use the "Start Automation" button to begin booking appointments
3. Monitor progress in real-time through the dashboard
4. Check logs for detailed information about each booking attempt

## 🔄 Keeping Your Fork Updated

If the original project gets updates:
1. In your forked Replit, click the "Pull from upstream" option
2. This will merge new features while keeping your configuration

## 🆘 Troubleshooting

### Common Issues:

**"Google credentials file not found"**
- Make sure `credentials.json` is uploaded to your project root
- Check that the service account has access to your Google Sheet

**"Configuration not working"**
- Use the "Configure URLs" button instead of manually setting environment variables
- Make sure your URLs are complete and valid

**"Browser automation failed"**
- Try setting "Headless Mode" to false to see what's happening
- Check that your LeadConnector URL is correct and accessible

**Email notifications not working**
- Verify your SendGrid API key is valid
- Check that the sender email is verified in SendGrid
- Use the "Test Email" button to diagnose issues

## 📞 Support

If you encounter issues:
1. Check the logs in the web interface
2. Review the configuration settings
3. Make sure all required credentials are properly set up

The app is designed to be self-contained and easy to share. Once forked, it should work independently in your account with just the credential setup!