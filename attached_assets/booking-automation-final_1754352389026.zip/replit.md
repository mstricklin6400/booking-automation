# Appointment Booking Automation

## Overview

This is a Python-based automation system that integrates Google Sheets with web automation to book appointments automatically. The application reads appointment data from a Google Spreadsheet and uses Playwright to automate the booking process on a third-party booking website. It provides both a Flask web interface for manual triggering and a command-line interface for direct execution.

## Recent Changes (Aug 4, 2025)

✓ Complete application architecture implemented with modular design
✓ Flask web dashboard with real-time status monitoring and control panel
✓ Comprehensive error handling and logging system
✓ Google Sheets integration with OAuth2 service account authentication  
✓ Playwright browser automation with multiple selector fallbacks
✓ Configuration management via environment variables
✓ Interactive credentials setup helper (setup_credentials.py)
✓ Complete documentation and README with setup instructions
✓ All dependencies installed and web interface running on port 5000
✓ Email notification system with SendGrid integration
✓ Notifications for booking success, failures, and automation summaries
✓ Email testing functionality in web dashboard
✓ Easy-to-use configuration management system with web-based URL setup
✓ Project fully shareable - users can fork and configure in under 5 minutes
✓ Comprehensive sharing guide and setup documentation created
✓ Configuration modal with form validation and user-friendly interface

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Flask Web Framework**: Provides a web interface for manual automation triggering and status monitoring
- **Modular Design**: Separated into distinct modules for configuration, automation logic, and web interface
- **Asynchronous Execution**: Uses threading to run automation tasks without blocking the web interface
- **Centralized Configuration**: Single config.py file manages all application settings with environment variable overrides

### Data Integration
- **Google Sheets API**: Primary data source using gspread library with OAuth2 service account authentication
- **Real-time Data Access**: Reads appointment data directly from Google Sheets without local storage
- **Status Tracking**: Updates Google Sheets to mark completed bookings

### Web Automation
- **Playwright Framework**: Handles browser automation for appointment booking
- **Headless/GUI Mode**: Configurable browser execution mode via environment variables
- **Error Handling**: Comprehensive error capture and logging for failed booking attempts

### Frontend Interface
- **Bootstrap 5**: Responsive web interface with modern styling
- **Real-time Updates**: JavaScript polling for automation status updates
- **Visual Status Indicators**: Color-coded status display with animations

### Logging and Monitoring
- **File-based Logging**: Persistent error logs in booking_errors.log
- **Console Output**: Real-time logging to standard output
- **Status Tracking**: Global status tracking for web interface updates

### Security Model
- **Service Account Authentication**: Google API access through service account credentials
- **Environment Variables**: Sensitive configuration stored as environment variables
- **Template-based Setup**: Credentials template prevents accidental exposure of secrets

## External Dependencies

### Google Services
- **Google Sheets API**: For reading appointment data from spreadsheets
- **Google Drive API**: For spreadsheet access permissions
- **OAuth2 Authentication**: Service account-based authentication for API access

### Third-party Booking Platform
- **LeadConnector HQ**: Target booking website for appointment automation
- **Web Form Automation**: Automated form filling and submission

### Python Libraries
- **Flask**: Web framework for the control interface
- **Playwright**: Browser automation and web scraping
- **gspread**: Google Sheets API client
- **oauth2client**: Google OAuth2 authentication

### Infrastructure Requirements
- **Chromium Browser**: Required by Playwright for web automation
- **File System Access**: For credentials storage and log file management
- **Network Access**: Required for Google API calls and web automation

### Configuration Management
- **Web-based Configuration**: Easy URL setup through browser interface
- **JSON Configuration Storage**: User settings saved to .replit_config.json
- **Environment Variables**: For flexible deployment configuration
- **JSON Credentials**: Google service account key file management
- **URL-based Sheet Access**: Supports both direct URLs and sheet IDs

### Sharing and Collaboration
- **Fork-Ready**: Project designed for easy forking and sharing on Replit
- **Auto-Setup**: Dependencies and configurations automatically install
- **User Isolation**: Each fork maintains independent configuration
- **Comprehensive Documentation**: Step-by-step guides for new users