"""
Email service module for sending booking notifications using SendGrid.
"""

import os
import sys
import logging
from typing import Optional, Dict, Any
from datetime import datetime

try:
    from sendgrid import SendGridAPIClient
    from sendgrid.helpers.mail import Mail, Email, To, Content
    SENDGRID_AVAILABLE = True
except ImportError:
    SENDGRID_AVAILABLE = False

class EmailService:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.api_key = os.environ.get('SENDGRID_API_KEY')
        self.from_email = os.environ.get('FROM_EMAIL', 'noreply@bookingautomation.com')
        self.notification_email = os.environ.get('NOTIFICATION_EMAIL')
        
        if not SENDGRID_AVAILABLE:
            self.logger.warning("SendGrid not available. Email notifications disabled.")
            self.enabled = False
        elif not self.api_key:
            self.logger.warning("SENDGRID_API_KEY not found. Email notifications disabled.")
            self.enabled = False
        else:
            self.enabled = True
            self.client = SendGridAPIClient(self.api_key)
            self.logger.info("Email service initialized successfully")

    def send_booking_success_notification(self, booking_data: Dict[str, Any]) -> bool:
        """Send notification for successful booking"""
        if not self.enabled or not self.notification_email:
            return False
        
        subject = f"✅ Booking Successful - {booking_data.get('name', 'Unknown')}"
        
        html_content = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background-color: #d1e7dd; color: #0f5132; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h2 style="margin: 0;">✅ Booking Successful!</h2>
            </div>
            
            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px;">
                <h3>Booking Details:</h3>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Name:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{booking_data.get('name', 'N/A')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Email:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{booking_data.get('email', 'N/A')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Company:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{booking_data.get('company', 'N/A')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Booked At:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</td>
                    </tr>
                </table>
            </div>
            
            <div style="margin-top: 20px; padding: 15px; background-color: #e2e3e5; border-radius: 8px; font-size: 12px; color: #6c757d;">
                This is an automated notification from your Appointment Booking System.
            </div>
        </div>
        """
        
        text_content = f"""
        BOOKING SUCCESSFUL
        
        Booking Details:
        - Name: {booking_data.get('name', 'N/A')}
        - Email: {booking_data.get('email', 'N/A')}
        - Company: {booking_data.get('company', 'N/A')}
        - Booked At: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        This is an automated notification from your Appointment Booking System.
        """
        
        return self._send_email(
            to_email=self.notification_email,
            subject=subject,
            html_content=html_content,
            text_content=text_content
        )

    def send_booking_failure_notification(self, booking_data: Dict[str, Any], error_message: str) -> bool:
        """Send notification for failed booking"""
        if not self.enabled or not self.notification_email:
            return False
        
        subject = f"❌ Booking Failed - {booking_data.get('name', 'Unknown')}"
        
        html_content = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background-color: #f8d7da; color: #721c24; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h2 style="margin: 0;">❌ Booking Failed</h2>
            </div>
            
            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h3>Attempted Booking Details:</h3>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Name:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{booking_data.get('name', 'N/A')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Email:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{booking_data.get('email', 'N/A')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Company:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{booking_data.get('company', 'N/A')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Failed At:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</td>
                    </tr>
                </table>
            </div>
            
            <div style="background-color: #fff3cd; color: #664d03; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h3 style="margin-top: 0;">Error Details:</h3>
                <p style="margin: 0; font-family: monospace; font-size: 14px;">{error_message}</p>
            </div>
            
            <div style="background-color: #cff4fc; color: #055160; padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <h4 style="margin-top: 0;">What to do next:</h4>
                <ul style="margin-bottom: 0;">
                    <li>Check the booking website is accessible</li>
                    <li>Verify the booking form hasn't changed</li>
                    <li>Review the automation logs for more details</li>
                    <li>Try running the booking manually to test</li>
                </ul>
            </div>
            
            <div style="margin-top: 20px; padding: 15px; background-color: #e2e3e5; border-radius: 8px; font-size: 12px; color: #6c757d;">
                This is an automated notification from your Appointment Booking System.
            </div>
        </div>
        """
        
        text_content = f"""
        BOOKING FAILED
        
        Attempted Booking Details:
        - Name: {booking_data.get('name', 'N/A')}
        - Email: {booking_data.get('email', 'N/A')}
        - Company: {booking_data.get('company', 'N/A')}
        - Failed At: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        Error Details:
        {error_message}
        
        What to do next:
        - Check the booking website is accessible
        - Verify the booking form hasn't changed
        - Review the automation logs for more details
        - Try running the booking manually to test
        
        This is an automated notification from your Appointment Booking System.
        """
        
        return self._send_email(
            to_email=self.notification_email,
            subject=subject,
            html_content=html_content,
            text_content=text_content
        )

    def send_automation_summary(self, summary_data: Dict[str, Any]) -> bool:
        """Send automation run summary"""
        if not self.enabled or not self.notification_email:
            return False
        
        subject = f"📊 Booking Automation Summary - {summary_data.get('total_processed', 0)} processed"
        
        html_content = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background-color: #cfe2ff; color: #084298; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <h2 style="margin: 0;">📊 Automation Run Complete</h2>
            </div>
            
            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px;">
                <h3>Summary Statistics:</h3>
                <table style="width: 100%; border-collapse: collapse;">
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Total Processed:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{summary_data.get('total_processed', 0)}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Successful Bookings:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; color: #198754;">{summary_data.get('successful', 0)}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Failed Bookings:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; color: #dc3545;">{summary_data.get('failed', 0)}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Skipped (Already Done):</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; color: #6c757d;">{summary_data.get('skipped', 0)}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6; font-weight: bold;">Run Time:</td>
                        <td style="padding: 8px; border-bottom: 1px solid #dee2e6;">{summary_data.get('duration', 'N/A')}</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; font-weight: bold;">Completed At:</td>
                        <td style="padding: 8px;">{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</td>
                    </tr>
                </table>
            </div>
            
            <div style="margin-top: 20px; padding: 15px; background-color: #e2e3e5; border-radius: 8px; font-size: 12px; color: #6c757d;">
                This is an automated summary from your Appointment Booking System.
            </div>
        </div>
        """
        
        text_content = f"""
        AUTOMATION RUN COMPLETE
        
        Summary Statistics:
        - Total Processed: {summary_data.get('total_processed', 0)}
        - Successful Bookings: {summary_data.get('successful', 0)}
        - Failed Bookings: {summary_data.get('failed', 0)}
        - Skipped (Already Done): {summary_data.get('skipped', 0)}
        - Run Time: {summary_data.get('duration', 'N/A')}
        - Completed At: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        This is an automated summary from your Appointment Booking System.
        """
        
        return self._send_email(
            to_email=self.notification_email,
            subject=subject,
            html_content=html_content,
            text_content=text_content
        )

    def _send_email(self, to_email: str, subject: str, html_content: str, text_content: str) -> bool:
        """Send email using SendGrid"""
        if not self.enabled:
            return False
        
        try:
            message = Mail(
                from_email=Email(self.from_email),
                to_emails=To(to_email),
                subject=subject
            )
            
            # Add both HTML and text content
            message.content = [
                Content("text/plain", text_content),
                Content("text/html", html_content)
            ]
            
            response = self.client.send(message)
            
            if response.status_code in [200, 201, 202]:
                self.logger.info(f"Email sent successfully to {to_email}")
                return True
            else:
                self.logger.error(f"Failed to send email. Status code: {response.status_code}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error sending email: {str(e)}")
            return False

    def test_email_setup(self) -> Dict[str, Any]:
        """Test email configuration and send test email"""
        result = {
            'sendgrid_available': SENDGRID_AVAILABLE,
            'api_key_configured': bool(self.api_key),
            'notification_email_configured': bool(self.notification_email),
            'service_enabled': self.enabled,
            'test_email_sent': False,
            'error': None
        }
        
        if not self.enabled:
            if not SENDGRID_AVAILABLE:
                result['error'] = "SendGrid library not available"
            elif not self.api_key:
                result['error'] = "SENDGRID_API_KEY environment variable not set"
            else:
                result['error'] = "Email service disabled for unknown reason"
            return result
        
        if not self.notification_email:
            result['error'] = "NOTIFICATION_EMAIL environment variable not set"
            return result
        
        # Send test email
        try:
            test_sent = self._send_email(
                to_email=self.notification_email,
                subject="🧪 Email Service Test - Booking Automation",
                html_content="""
                <div style="font-family: Arial, sans-serif; padding: 20px;">
                    <h2>🧪 Email Service Test</h2>
                    <p>This is a test email from your Appointment Booking Automation system.</p>
                    <p>If you received this email, the email notifications are working correctly!</p>
                    <hr>
                    <small>Test sent at: """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + """</small>
                </div>
                """,
                text_content=f"""
                EMAIL SERVICE TEST
                
                This is a test email from your Appointment Booking Automation system.
                If you received this email, the email notifications are working correctly!
                
                Test sent at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
                """
            )
            
            result['test_email_sent'] = test_sent
            if not test_sent:
                result['error'] = "Test email failed to send"
                
        except Exception as e:
            result['error'] = f"Test email error: {str(e)}"
        
        return result