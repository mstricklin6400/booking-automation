#!/usr/bin/env python3
"""
Main entry point for the appointment booking automation.
Can be run directly or through the Flask web interface.
"""

import sys
import os
import logging
from booking_automation import BookingAutomation

def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('booking_errors.log'),
            logging.StreamHandler(sys.stdout)
        ]
    )

def main():
    """Main function to run the booking automation"""
    setup_logging()
    logger = logging.getLogger(__name__)
    
    try:
        logger.info("Starting appointment booking automation...")
        automation = BookingAutomation()
        automation.run()
        logger.info("Automation completed successfully!")
    except Exception as e:
        logger.error(f"Critical error in main: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
