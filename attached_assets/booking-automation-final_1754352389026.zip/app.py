"""
Flask web application for manually triggering the booking automation.
Provides a simple web interface to run the automation and view logs.
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for
import logging
import json
import os
import threading
from datetime import datetime
from booking_automation import BookingAutomation
from config import Config
from config_manager import ConfigManager
from email_service import EmailService

app = Flask(__name__)
app.secret_key = Config.SECRET_KEY

# Load configuration on startup
ConfigManager.load_config()

# Global variable to track automation status
automation_status = {
    'running': False,
    'last_run': None,
    'last_result': None
}

def setup_logging():
    """Setup logging for the Flask app"""
    logging.basicConfig(
        level=getattr(logging, Config.LOG_LEVEL),
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('booking_errors.log'),
            logging.StreamHandler()
        ]
    )

def run_automation_async():
    """Run automation in a separate thread"""
    global automation_status
    
    try:
        automation_status['running'] = True
        automation_status['last_result'] = None
        
        automation = BookingAutomation()
        automation.run()
        
        automation_status['last_result'] = {
            'success': True,
            'message': 'Automation completed successfully',
            'failed_count': len(automation.failed_bookings)
        }
        
    except Exception as e:
        automation_status['last_result'] = {
            'success': False,
            'message': f'Automation failed: {str(e)}',
            'failed_count': 0
        }
        
    finally:
        automation_status['running'] = False
        automation_status['last_run'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

@app.route('/')
def index():
    """Main dashboard page"""
    return render_template('index.html', status=automation_status)

@app.route('/run_automation', methods=['POST'])
def run_automation():
    """Trigger the booking automation"""
    global automation_status
    
    if automation_status['running']:
        return jsonify({
            'success': False,
            'message': 'Automation is already running'
        })
    
    # Validate configuration
    config_errors = Config.validate_config()
    if config_errors:
        return jsonify({
            'success': False,
            'message': 'Configuration errors: ' + ', '.join(config_errors)
        })
    
    # Start automation in background thread
    thread = threading.Thread(target=run_automation_async)
    thread.daemon = True
    thread.start()
    
    return jsonify({
        'success': True,
        'message': 'Automation started successfully'
    })

@app.route('/status')
def get_status():
    """Get current automation status"""
    return jsonify(automation_status)

@app.route('/logs')
def view_logs():
    """View recent log entries"""
    try:
        logs = []
        
        # Read error logs
        if os.path.exists('booking_errors.log'):
            with open('booking_errors.log', 'r') as f:
                lines = f.readlines()
                # Get last 50 lines
                logs.extend(lines[-50:])
        
        return jsonify({
            'success': True,
            'logs': logs
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error reading logs: {str(e)}'
        })

@app.route('/failed_bookings')
def view_failed_bookings():
    """View failed booking attempts"""
    try:
        failed_bookings = []
        
        if os.path.exists('failed_bookings.log'):
            with open('failed_bookings.log', 'r') as f:
                for line in f:
                    try:
                        failed_bookings.append(json.loads(line.strip()))
                    except:
                        continue
        
        return jsonify({
            'success': True,
            'failed_bookings': failed_bookings[-20:]  # Last 20 failed attempts
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error reading failed bookings: {str(e)}'
        })

@app.route('/config')
def config():
    """Get configuration status"""
    try:
        config_items = ConfigManager.get_config_status()
        
        return jsonify({
            'success': True,
            'config': config_items
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/update_config', methods=['POST'])
def update_config():
    """Update configuration settings"""
    try:
        updates = request.get_json()
        
        if not updates:
            return jsonify({
                'success': False,
                'error': 'No configuration data provided'
            })
        
        # Validate required fields
        valid_fields = {
            'SPREADSHEET_URL', 'BOOKING_URL', 'SHEET_NAME', 'HEADLESS_MODE',
            'NOTIFICATION_EMAIL', 'FROM_EMAIL', 'EMAIL_NOTIFICATIONS_ENABLED',
            'NOTIFY_ON_SUCCESS', 'NOTIFY_ON_FAILURE', 'NOTIFY_ON_SUMMARY'
        }
        
        filtered_updates = {k: v for k, v in updates.items() if k in valid_fields}
        
        if ConfigManager.update_config(filtered_updates):
            return jsonify({
                'success': True,
                'message': 'Configuration updated successfully'
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to save configuration'
            })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/get_config_form')
def get_config_form():
    """Get current configuration for editing"""
    try:
        config = ConfigManager.load_config()
        return jsonify({
            'success': True,
            'config': config
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/test_email', methods=['POST'])
def test_email():
    """Test email configuration and send test email"""
    try:
        email_service = EmailService()
        test_result = email_service.test_email_setup()
        
        return jsonify({
            'success': test_result.get('test_email_sent', False),
            'result': test_result
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.route('/email_config')
def email_config():
    """Get detailed email configuration status"""
    try:
        email_service = EmailService()
        config_status = email_service.test_email_setup()
        
        return jsonify({
            'success': True,
            'email_config': config_status
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

@app.errorhandler(404)
def not_found(error):
    return render_template('index.html', status=automation_status), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        'success': False,
        'message': 'Internal server error'
    }), 500

if __name__ == '__main__':
    setup_logging()
    
    # Validate configuration on startup
    config_errors = Config.validate_config()
    if config_errors:
        print("Configuration Errors:")
        for error in config_errors:
            print(f"  - {error}")
        print("\nNote: These issues can be fixed through the web interface.")
    else:
        print("Configuration validated successfully!")
    
    print(f"Starting Flask app on {Config.FLASK_HOST}:{Config.FLASK_PORT}")
    app.run(
        host=Config.FLASK_HOST,
        port=Config.FLASK_PORT,
        debug=Config.FLASK_DEBUG
    )
