"""
Configuration manager for easy setup and management of environment variables.
"""

import os
import json
from pathlib import Path

class ConfigManager:
    """Manages configuration settings and environment variables"""
    
    CONFIG_FILE = ".replit_config.json"
    
    DEFAULT_CONFIG = {
        "SPREADSHEET_URL": "",
        "BOOKING_URL": "https://api.leadconnectorhq.com/widget/booking/vggoBfO4Zr1RTp4M4h8m",
        "SHEET_NAME": "Sheet1",
        "HEADLESS_MODE": "true",
        "FLASK_PORT": "5000",
        "NOTIFICATION_EMAIL": "",
        "FROM_EMAIL": "noreply@bookingautomation.com",
        "EMAIL_NOTIFICATIONS_ENABLED": "true",
        "NOTIFY_ON_SUCCESS": "true",
        "NOTIFY_ON_FAILURE": "true",
        "NOTIFY_ON_SUMMARY": "true"
    }
    
    @classmethod
    def load_config(cls):
        """Load configuration from file or create default"""
        config_path = Path(cls.CONFIG_FILE)
        
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    config = json.load(f)
            except (json.JSONDecodeError, IOError):
                config = cls.DEFAULT_CONFIG.copy()
        else:
            config = cls.DEFAULT_CONFIG.copy()
        
        # Update environment variables
        for key, value in config.items():
            if value:  # Only set non-empty values
                os.environ[key] = str(value)
        
        return config
    
    @classmethod
    def save_config(cls, config):
        """Save configuration to file and update environment variables"""
        try:
            with open(cls.CONFIG_FILE, 'w') as f:
                json.dump(config, f, indent=2)
            
            # Update environment variables
            for key, value in config.items():
                if value:  # Only set non-empty values
                    os.environ[key] = str(value)
                elif key in os.environ:
                    # Remove empty values from environment
                    del os.environ[key]
            
            return True
        except IOError:
            return False
    
    @classmethod
    def update_config(cls, updates):
        """Update specific configuration values"""
        config = cls.load_config()
        config.update(updates)
        return cls.save_config(config)
    
    @classmethod
    def get_config_status(cls):
        """Get current configuration status for display"""
        config = cls.load_config()
        
        status_items = []
        
        # Check Google Sheets configuration
        spreadsheet_url = config.get('SPREADSHEET_URL', '')
        if spreadsheet_url:
            if 'docs.google.com' in spreadsheet_url:
                status_items.append({
                    'label': 'Google Sheet',
                    'value': 'Configured',
                    'type': 'status',
                    'details': spreadsheet_url
                })
            else:
                status_items.append({
                    'label': 'Google Sheet',
                    'value': 'Invalid URL',
                    'type': 'status',
                    'details': spreadsheet_url
                })
        else:
            status_items.append({
                'label': 'Google Sheet',
                'value': 'Not Set',
                'type': 'status'
            })
        
        # Check LeadConnector URL
        booking_url = config.get('BOOKING_URL', '')
        if booking_url:
            if 'leadconnectorhq.com' in booking_url:
                status_items.append({
                    'label': 'LeadConnector URL',
                    'value': 'Configured',
                    'type': 'status',
                    'details': booking_url
                })
            else:
                status_items.append({
                    'label': 'LeadConnector URL',
                    'value': 'Invalid URL',
                    'type': 'status',
                    'details': booking_url
                })
        else:
            status_items.append({
                'label': 'LeadConnector URL',
                'value': 'Not Set',
                'type': 'status'
            })
        
        # Check Google credentials
        creds_file = os.getenv("GOOGLE_CREDS_FILE", "credentials.json")
        if os.path.exists(creds_file):
            status_items.append({
                'label': 'Google Credentials',
                'value': 'Found',
                'type': 'status'
            })
        else:
            status_items.append({
                'label': 'Google Credentials',
                'value': 'Missing',
                'type': 'status'
            })
        
        # Check email configuration
        sendgrid_key = os.getenv('SENDGRID_API_KEY')
        notification_email = config.get('NOTIFICATION_EMAIL', '')
        
        if sendgrid_key and notification_email:
            status_items.append({
                'label': 'Email Notifications',
                'value': 'Enabled',
                'type': 'status'
            })
        else:
            status_items.append({
                'label': 'Email Notifications',
                'value': 'Disabled',
                'type': 'status'
            })
        
        return status_items
    
    @classmethod
    def reset_to_defaults(cls):
        """Reset configuration to default values"""
        return cls.save_config(cls.DEFAULT_CONFIG.copy())