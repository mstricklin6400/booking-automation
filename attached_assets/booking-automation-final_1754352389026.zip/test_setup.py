#!/usr/bin/env python3
"""
Test script to validate the appointment booking automation setup.
"""

import os
import json
import sys
from booking_automation import BookingAutomation
from config import Config

def test_credentials():
    """Test Google Service Account credentials"""
    print("🔐 Testing Google Service Account credentials...")
    
    if not os.path.exists(Config.CREDS_FILE):
        print(f"❌ Credentials file not found: {Config.CREDS_FILE}")
        return False
    
    try:
        with open(Config.CREDS_FILE, 'r') as f:
            creds = json.load(f)
        
        required_fields = ["type", "project_id", "private_key", "client_email"]
        missing_fields = [field for field in required_fields if field not in creds]
        
        if missing_fields:
            print(f"❌ Missing required fields: {', '.join(missing_fields)}")
            return False
        
        if creds.get("type") != "service_account":
            print("❌ Invalid credential type (should be 'service_account')")
            return False
        
        print(f"✅ Credentials valid!")
        print(f"   📧 Service Account: {creds['client_email']}")
        print(f"   📋 Project ID: {creds['project_id']}")
        return True
        
    except json.JSONDecodeError:
        print("❌ Invalid JSON format in credentials file")
        return False
    except Exception as e:
        print(f"❌ Error reading credentials: {e}")
        return False

def test_google_sheets_connection():
    """Test connection to Google Sheets"""
    print("\n📊 Testing Google Sheets connection...")
    
    try:
        automation = BookingAutomation()
        sheet = automation.get_sheet()
        
        # Try to get sheet properties
        sheet_info = sheet.get_all_records()
        print(f"✅ Connected to Google Sheets successfully!")
        print(f"   📄 Found {len(sheet_info)} rows of data")
        
        if len(sheet_info) > 0:
            print("   📋 Sample data structure:")
            sample_row = sheet_info[0]
            for key in sample_row.keys():
                print(f"      - {key}: {sample_row[key]}")
        
        return True
        
    except Exception as e:
        print(f"❌ Google Sheets connection failed: {e}")
        print("   💡 Make sure to:")
        print("      1. Share your sheet with the service account email")
        print("      2. Check the SPREADSHEET_URL in your configuration")
        return False

def test_configuration():
    """Test application configuration"""
    print("\n⚙️  Testing configuration...")
    
    config_errors = Config.validate_config()
    if config_errors:
        print("❌ Configuration errors found:")
        for error in config_errors:
            print(f"   - {error}")
        return False
    
    print("✅ Configuration is valid!")
    print(f"   🔗 Spreadsheet URL: {Config.SPREADSHEET_URL[:50]}...")
    print(f"   🌐 Booking URL: {Config.BOOKING_URL}")
    print(f"   👻 Headless Mode: {Config.HEADLESS_MODE}")
    return True

def test_playwright_setup():
    """Test Playwright browser setup"""
    print("\n🎭 Testing Playwright setup...")
    
    try:
        from playwright.sync_api import sync_playwright
        
        with sync_playwright() as p:
            # Try to launch browser
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            
            # Test basic navigation
            page.goto("https://www.google.com")
            title = page.title()
            browser.close()
            
            print("✅ Playwright is working correctly!")
            print(f"   🌐 Test navigation successful (title: {title[:30]}...)")
            return True
            
    except Exception as e:
        print(f"❌ Playwright test failed: {e}")
        print("   💡 Try running: playwright install")
        return False

def main():
    """Run all tests"""
    print("🧪 Appointment Booking Automation - Setup Test")
    print("=" * 60)
    
    tests = [
        ("Configuration", test_configuration),
        ("Credentials", test_credentials),
        ("Google Sheets", test_google_sheets_connection),
        ("Playwright Browser", test_playwright_setup)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        result = test_func()
        results.append((test_name, result))
    
    print("\n" + "=" * 60)
    print("📋 Test Summary:")
    
    all_passed = True
    for test_name, passed in results:
        status = "✅ PASS" if passed else "❌ FAIL" 
        print(f"   {status} {test_name}")
        if not passed:
            all_passed = False
    
    print("\n" + "=" * 60)
    
    if all_passed:
        print("🎉 All tests passed! Your setup is ready to go.")
        print("   Run 'python app.py' to start the web interface")
        print("   or 'python main.py' for command-line automation")
    else:
        print("⚠️  Some tests failed. Please fix the issues above before running the automation.")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())