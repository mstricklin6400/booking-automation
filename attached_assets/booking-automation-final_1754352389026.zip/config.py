"""
Configuration settings for the booking automation application.
"""

import os

class Config:
    """Configuration class that handles all application settings"""
    
    # Google Sheets Configuration
    SCOPE = [
        "https://spreadsheets.google.com/feeds",
        "https://www.googleapis.com/auth/drive"
    ]
    
    # Credentials file - should be placed in the project root
    CREDS_FILE = os.getenv("GOOGLE_CREDS_FILE", "credentials.json")
    
    # Google Sheet URL or ID - can be overridden via environment variable
    SPREADSHEET_URL = os.getenv(
        "SPREADSHEET_URL",
        "https://docs.google.com/spreadsheets/d/e/2PACX-1vTKXrh3wD_skKKhCAPQJPoLR-t1JjYsbAP7qHNW6YWMej7VAYRwpmnizwhGN_bbTzRolac2DdcEa1d2/pub?output=csv"
    )
    
    # Sheet name (tab name in the spreadsheet)
    SHEET_NAME = os.getenv("SHEET_NAME", "Sheet1")
    
    # Booking Configuration
    BOOKING_URL = os.getenv(
        "BOOKING_URL",
        "https://api.leadconnectorhq.com/widget/booking/vggoBfO4Zr1RTp4M4h8m"
    )
    
    # Playwright Configuration
    HEADLESS_MODE = os.getenv("HEADLESS_MODE", "True").lower() == "true"
    
    # Flask Configuration
    FLASK_HOST = os.getenv("FLASK_HOST", "0.0.0.0")
    FLASK_PORT = int(os.getenv("FLASK_PORT", "5000"))
    FLASK_DEBUG = os.getenv("FLASK_DEBUG", "False").lower() == "true"
    SECRET_KEY = os.getenv("SECRET_KEY", "your-secret-key-change-this")
    
    # Logging Configuration
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    # Email Configuration
    SENDGRID_API_KEY = os.getenv("SENDGRID_API_KEY")
    FROM_EMAIL = os.getenv("FROM_EMAIL", "noreply@bookingautomation.com")
    NOTIFICATION_EMAIL = os.getenv("NOTIFICATION_EMAIL")
    EMAIL_NOTIFICATIONS_ENABLED = os.getenv("EMAIL_NOTIFICATIONS_ENABLED", "True").lower() == "true"
    
    # Email notification settings
    NOTIFY_ON_SUCCESS = os.getenv("NOTIFY_ON_SUCCESS", "True").lower() == "true"
    NOTIFY_ON_FAILURE = os.getenv("NOTIFY_ON_FAILURE", "True").lower() == "true"
    NOTIFY_ON_SUMMARY = os.getenv("NOTIFY_ON_SUMMARY", "True").lower() == "true"
    
    @classmethod
    def validate_config(cls):
        """Validate that all required configuration is present"""
        errors = []
        
        if not os.path.exists(cls.CREDS_FILE):
            errors.append(f"Google credentials file not found: {cls.CREDS_FILE}")
        
        if not cls.SPREADSHEET_URL:
            errors.append("SPREADSHEET_URL is required")
        
        if not cls.BOOKING_URL:
            errors.append("BOOKING_URL is required")
        
        return errors
    
    @classmethod
    def get_email_config_info(cls):
        """Get email configuration information for display"""
        return {
            'sendgrid_configured': bool(cls.SENDGRID_API_KEY),
            'notification_email_set': bool(cls.NOTIFICATION_EMAIL),
            'from_email': cls.FROM_EMAIL,
            'notifications_enabled': cls.EMAIL_NOTIFICATIONS_ENABLED,
            'notify_on_success': cls.NOTIFY_ON_SUCCESS,
            'notify_on_failure': cls.NOTIFY_ON_FAILURE,
            'notify_on_summary': cls.NOTIFY_ON_SUMMARY
        }
